import { neon } from "@netlify/neon";

export default async (req) => {
  const sql = neon();
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  if (req.method === "OPTIONS") return new Response("ok", { headers });

  try {
    // GET requests
    if (req.method === "GET") {
      const url = new URL(req.url);
      const action = url.searchParams.get("action");
      const date = url.searchParams.get("date");

      if (action === "get" && date) {
        const rows = await sql`SELECT data FROM daily_sales WHERE date_key = ${date}`;
        return new Response(JSON.stringify({ data: rows[0]?.data || null }), { headers });
      }

      if (action === "getAll") {
        const rows = await sql`SELECT date_key, data FROM daily_sales ORDER BY date_key`;
        const out = {};
        for (const r of rows) out[r.date_key] = r.data;
        return new Response(JSON.stringify({ data: out }), { headers });
      }

      if (action === "init") {
        await sql`CREATE TABLE IF NOT EXISTS daily_sales (
          date_key TEXT PRIMARY KEY,
          data JSONB NOT NULL DEFAULT '{}'::jsonb
        )`;
        return new Response(JSON.stringify({ ok: true, message: "Table created" }), { headers });
      }

      return new Response(JSON.stringify({ error: "Unknown action" }), { status: 400, headers });
    }

    // POST requests
    if (req.method === "POST") {
      const body = await req.json();

      if (body.action === "set" && body.date && body.data) {
        await sql`INSERT INTO daily_sales (date_key, data) VALUES (${body.date}, ${JSON.stringify(body.data)}::jsonb)
          ON CONFLICT (date_key) DO UPDATE SET data = ${JSON.stringify(body.data)}::jsonb`;
        return new Response(JSON.stringify({ ok: true }), { headers });
      }

      return new Response(JSON.stringify({ error: "Invalid body" }), { status: 400, headers });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  } catch (e) {
    console.error("API Error:", e);
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
};

export const config = { path: "/api/*" };
